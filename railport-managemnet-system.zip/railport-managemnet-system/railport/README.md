# RailPort — On-Demand Porter Booking System

A DBMS project: PostgreSQL + Node/Express (REST API) + React (Vite).
Three role-based experiences on one codebase: **Passenger**, **Porter**, and **Admin**.

## Project structure

```
railport/
├── database/
│   ├── schema.sql     → creates all 7 tables (3NF, PK/FK/CHECK constraints, indexes)
│   └── seed.sql        → sample data — all seeded accounts use password: password123
├── backend/             → Express REST API + auth
└── frontend/             → React app (Vite) — routes by role after login
```

## Setup — step by step

### 1. Prerequisites
- PostgreSQL installed and running
- Node.js v18+ and npm

### 2. Database

```bash
psql -U postgres
CREATE DATABASE railport_db;
\c railport_db
\i database/schema.sql
\i database/seed.sql
```

### 3. Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` with your actual Postgres password, then:

```bash
npm run dev
```

Check it: `http://localhost:5000/api/stations` should return the 3 seeded stations.

### 4. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Demo accounts (password: `password123` for all)

| Role      | Phone      | What you'll see |
|-----------|------------|---|
| Passenger | 9876543210 | Book a Porter, My Bookings (pay / rate) |
| Porter    | 9876543211 | Available Requests, My Bookings, My Ratings |
| Admin     | 9876543212 | Full CRUD console across all 7 tables |

You can also register fresh accounts from the login screen — porters provide
a home station and badge number at signup, which creates their linked
`porters` row automatically.

## How the three apps fit together

```
                         ┌─────────────┐
                         │   Login     │
                         └──────┬──────┘
                    role from users.role
        ┌──────────────────────┼──────────────────────┐
        ▼                      ▼                       ▼
  PASSENGER APP           PORTER APP              ADMIN APP
  Book a Porter    Available Requests /       Full CRUD console
  My Bookings      My Bookings / Ratings      (all 7 tables)
  Pay, Rate        Accept, Start, Complete
        │                      │                       │
        └──────────────────────┴───────────────────────┘
                               │
                     Express REST API (JWT-free,
                     bcrypt-hashed passwords)
                               │
                          PostgreSQL
```

A booking a passenger creates shows up live as an "open request" for any
available porter at that station; a porter accepting it links `porter_id`
on the booking row and flips their own `availability_status` to BUSY —
the same foreign keys from the ER diagram, exercised through the UI.

## Architecture

```
React (5173)  →  HTTP/REST  →  Express (5000)  →  pg  →  PostgreSQL (5432)
```

No ORM — all queries in `backend/controllers/` are raw parameterized SQL,
so the DBMS concepts stay visible. Passwords are hashed with bcrypt
(`authController.js`); there's no JWT/session token — the logged-in user's
info is kept in the frontend and persisted to `localStorage`, which is
enough for a class project but noted as a real gap (see Future Work).

## What's implemented

- [x] Normalized schema (3NF), PK/FK/CHECK constraints, indexes
- [x] Full CRUD REST API for all 7 tables
- [x] Registration & login (bcrypt password hashing) for passenger/porter/admin
- [x] Passenger flow: book → (porter accepts) → pay (simulated) → rate
- [x] Porter flow: toggle availability → accept open requests → advance booking status
- [x] Admin CRUD console (unchanged from earlier milestone)

## Future work (Phase 5 — not yet built)

- [ ] JWT-based sessions instead of client-held user info
- [ ] Triggers — auto-update porter `availability_status` on booking complete/cancel;
      recompute `porters.rating` after each new review
- [ ] Views for admin revenue/usage reporting
- [ ] Transactions wrapping multi-step operations beyond registration
- [ ] Automated porter assignment by proximity, not just station
- [ ] Real payment gateway (currently a simulated "Pay" button)
