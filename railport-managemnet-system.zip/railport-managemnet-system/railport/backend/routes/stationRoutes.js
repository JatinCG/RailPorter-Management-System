const express = require('express');
const router = express.Router();
const controller = require('../controllers/stationController');

router.post('/', controller.createStation);
router.get('/', controller.getStations);
router.get('/:id', controller.getStationById);
router.put('/:id', controller.updateStation);
router.delete('/:id', controller.deleteStation);

module.exports = router;
