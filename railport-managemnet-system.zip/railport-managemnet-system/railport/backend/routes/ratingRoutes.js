const express = require('express');
const router = express.Router();
const controller = require('../controllers/ratingController');

router.post('/', controller.createRating);
router.get('/', controller.getRatings);
router.get('/:id', controller.getRatingById);
router.put('/:id', controller.updateRating);
router.delete('/:id', controller.deleteRating);

module.exports = router;
