const express = require('express');
const router = express.Router();
const controller = require('../controllers/porterController');

router.post('/', controller.createPorter);
router.get('/', controller.getPorters);
router.get('/:id', controller.getPorterById);
router.put('/:id', controller.updatePorter);
router.delete('/:id', controller.deletePorter);

module.exports = router;
