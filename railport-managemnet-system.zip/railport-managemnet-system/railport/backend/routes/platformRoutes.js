const express = require('express');
const router = express.Router();
const controller = require('../controllers/platformController');

router.post('/', controller.createPlatform);
router.get('/', controller.getPlatforms);
router.get('/:id', controller.getPlatformById);
router.put('/:id', controller.updatePlatform);
router.delete('/:id', controller.deletePlatform);

module.exports = router;
