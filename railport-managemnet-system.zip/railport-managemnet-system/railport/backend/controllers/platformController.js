const pool = require('../config/db');

exports.createPlatform = async (req, res) => {
  try {
    const { station_id, platform_number } = req.body;
    const result = await pool.query(
      `INSERT INTO platforms (station_id, platform_number) VALUES ($1, $2) RETURNING *`,
      [station_id, platform_number]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getPlatforms = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, s.station_name FROM platforms p
       JOIN stations s ON p.station_id = s.station_id
       ORDER BY p.platform_id`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getPlatformById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM platforms WHERE platform_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Platform not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updatePlatform = async (req, res) => {
  try {
    const { id } = req.params;
    const { station_id, platform_number } = req.body;
    const result = await pool.query(
      `UPDATE platforms SET station_id = $1, platform_number = $2
       WHERE platform_id = $3 RETURNING *`,
      [station_id, platform_number, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Platform not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deletePlatform = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM platforms WHERE platform_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Platform not found' });
    res.json({ message: 'Platform deleted', platform: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
