const pool = require('../config/db');

exports.createBooking = async (req, res) => {
  try {
    const {
      passenger_id, porter_id, station_id, pickup_platform_id,
      train_number, coach_number, luggage_count, destination, fare
    } = req.body;
    const result = await pool.query(
      `INSERT INTO bookings
       (passenger_id, porter_id, station_id, pickup_platform_id, train_number,
        coach_number, luggage_count, destination, fare, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'REQUESTED') RETURNING *`,
      [passenger_id, porter_id || null, station_id, pickup_platform_id || null,
       train_number, coach_number, luggage_count || 1, destination, fare || 0]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Supports optional query filters so the passenger/porter apps can ask for
// just their own bookings instead of the whole table:
//   /api/bookings?passenger_id=3         -> a passenger's own bookings
//   /api/bookings?porter_id=2            -> a porter's assigned bookings
//   /api/bookings?station_id=1&status=REQUESTED&unassigned=true
//                                         -> open requests a porter can accept
exports.getBookings = async (req, res) => {
  try {
    const { passenger_id, porter_id, station_id, status, unassigned } = req.query;
    const conditions = [];
    const values = [];

    if (passenger_id) { values.push(passenger_id); conditions.push(`b.passenger_id = $${values.length}`); }
    if (porter_id)    { values.push(porter_id);    conditions.push(`b.porter_id = $${values.length}`); }
    if (station_id)   { values.push(station_id);   conditions.push(`b.station_id = $${values.length}`); }
    if (status)       { values.push(status);       conditions.push(`b.status = $${values.length}`); }
    if (unassigned === 'true') { conditions.push('b.porter_id IS NULL'); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await pool.query(
      `SELECT b.*, up.name AS passenger_name, s.station_name,
              upr.name AS porter_name, pl.platform_number
       FROM bookings b
       JOIN users up ON b.passenger_id = up.user_id
       JOIN stations s ON b.station_id = s.station_id
       LEFT JOIN porters p ON b.porter_id = p.porter_id
       LEFT JOIN users upr ON p.user_id = upr.user_id
       LEFT JOIN platforms pl ON b.pickup_platform_id = pl.platform_id
       ${where}
       ORDER BY b.booking_id DESC`,
      values
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getBookingById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT b.*, up.name AS passenger_name, s.station_name
       FROM bookings b
       JOIN users up ON b.passenger_id = up.user_id
       JOIN stations s ON b.station_id = s.station_id
       WHERE b.booking_id = $1`,
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Booking not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update mainly used for status transitions: REQUESTED -> ACCEPTED -> IN_PROGRESS -> COMPLETED/CANCELLED
exports.updateBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const { porter_id, status, fare, completed_at } = req.body;
    const result = await pool.query(
      `UPDATE bookings SET porter_id = COALESCE($1, porter_id),
                            status = COALESCE($2, status),
                            fare = COALESCE($3, fare),
                            completed_at = COALESCE($4, completed_at)
       WHERE booking_id = $5 RETURNING *`,
      [porter_id, status, fare, completed_at, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Booking not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM bookings WHERE booking_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Booking not found' });
    res.json({ message: 'Booking deleted', booking: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
