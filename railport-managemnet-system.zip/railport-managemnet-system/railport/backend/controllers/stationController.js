const pool = require('../config/db');

exports.createStation = async (req, res) => {
  try {
    const { station_name, station_code, city, number_of_platforms } = req.body;
    const result = await pool.query(
      `INSERT INTO stations (station_name, station_code, city, number_of_platforms)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [station_name, station_code, city, number_of_platforms]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStations = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM stations ORDER BY station_id');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStationById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM stations WHERE station_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Station not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateStation = async (req, res) => {
  try {
    const { id } = req.params;
    const { station_name, station_code, city, number_of_platforms } = req.body;
    const result = await pool.query(
      `UPDATE stations SET station_name = $1, station_code = $2, city = $3, number_of_platforms = $4
       WHERE station_id = $5 RETURNING *`,
      [station_name, station_code, city, number_of_platforms, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Station not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteStation = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM stations WHERE station_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Station not found' });
    res.json({ message: 'Station deleted', station: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
