const pool = require('../config/db');

exports.createRating = async (req, res) => {
  try {
    const { booking_id, passenger_id, porter_id, stars, review } = req.body;
    const result = await pool.query(
      `INSERT INTO ratings (booking_id, passenger_id, porter_id, stars, review)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [booking_id, passenger_id, porter_id, stars, review || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Optional filters: /api/ratings?porter_id=1  (a porter's received ratings)
//                    /api/ratings?passenger_id=1&booking_id=3
exports.getRatings = async (req, res) => {
  try {
    const { porter_id, passenger_id, booking_id } = req.query;
    const conditions = [];
    const values = [];

    if (porter_id)     { values.push(porter_id);     conditions.push(`r.porter_id = $${values.length}`); }
    if (passenger_id)  { values.push(passenger_id);  conditions.push(`r.passenger_id = $${values.length}`); }
    if (booking_id)    { values.push(booking_id);    conditions.push(`r.booking_id = $${values.length}`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await pool.query(
      `SELECT r.*, up.name AS passenger_name, u2.name AS porter_name
       FROM ratings r
       JOIN users up ON r.passenger_id = up.user_id
       JOIN porters p ON r.porter_id = p.porter_id
       JOIN users u2 ON p.user_id = u2.user_id
       ${where}
       ORDER BY r.rating_id DESC`,
      values
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getRatingById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM ratings WHERE rating_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Rating not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateRating = async (req, res) => {
  try {
    const { id } = req.params;
    const { stars, review } = req.body;
    const result = await pool.query(
      `UPDATE ratings SET stars = $1, review = $2 WHERE rating_id = $3 RETURNING *`,
      [stars, review, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Rating not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteRating = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM ratings WHERE rating_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Rating not found' });
    res.json({ message: 'Rating deleted', rating: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
