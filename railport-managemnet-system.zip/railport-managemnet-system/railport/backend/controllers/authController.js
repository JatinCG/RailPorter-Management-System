const pool = require('../config/db');
const bcrypt = require('bcryptjs');

// Registers a user. If role = 'PORTER', also creates the linked porters row
// (station + badge number) in the same request, since a porter can't exist
// without both a user record and a porter record.
exports.register = async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, phone, email, password, role, station_id, badge_number } = req.body;

    if (!name || !phone || !password || !role) {
      return res.status(400).json({ error: 'name, phone, password and role are required' });
    }
    if (role === 'PORTER' && (!station_id || !badge_number)) {
      return res.status(400).json({ error: 'Porters must provide station_id and badge_number' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    await client.query('BEGIN');

    const userResult = await client.query(
      `INSERT INTO users (name, phone, email, password, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING user_id, name, phone, email, role, created_at`,
      [name, phone, email || null, passwordHash, role]
    );
    const user = userResult.rows[0];

    let porter = null;
    if (role === 'PORTER') {
      const porterResult = await client.query(
        `INSERT INTO porters (user_id, station_id, badge_number, availability_status)
         VALUES ($1, $2, $3, 'OFFLINE')
         RETURNING *`,
        [user.user_id, station_id, badge_number]
      );
      porter = porterResult.rows[0];
    }

    await client.query('COMMIT');
    res.status(201).json({ user, porter });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
};

// Logs a user in by phone + password. Returns the user (without password
// hash) and, if the user is a porter, their porter record too — the
// frontend needs porter_id to file "my bookings" queries.
exports.login = async (req, res) => {
  try {
    const { phone, password } = req.body;
    if (!phone || !password) {
      return res.status(400).json({ error: 'phone and password are required' });
    }

    const userResult = await pool.query('SELECT * FROM users WHERE phone = $1', [phone]);
    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid phone or password' });
    }
    const user = userResult.rows[0];

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: 'Invalid phone or password' });
    }
    delete user.password;

    let porter = null;
    if (user.role === 'PORTER') {
      const porterResult = await pool.query('SELECT * FROM porters WHERE user_id = $1', [user.user_id]);
      porter = porterResult.rows[0] || null;
    }

    res.json({ user, porter });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
