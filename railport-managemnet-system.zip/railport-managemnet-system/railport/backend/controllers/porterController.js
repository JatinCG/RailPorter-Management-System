const pool = require('../config/db');

exports.createPorter = async (req, res) => {
  try {
    const { user_id, station_id, badge_number, availability_status, current_platform_id } = req.body;
    const result = await pool.query(
      `INSERT INTO porters (user_id, station_id, badge_number, availability_status, current_platform_id)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [user_id, station_id, badge_number, availability_status || 'OFFLINE', current_platform_id || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Optional filters: /api/porters?user_id=6  (find "my" porter row after login)
//                    /api/porters?station_id=1&availability_status=AVAILABLE
exports.getPorters = async (req, res) => {
  try {
    const { user_id, station_id, availability_status } = req.query;
    const conditions = [];
    const values = [];

    if (user_id)             { values.push(user_id);             conditions.push(`p.user_id = $${values.length}`); }
    if (station_id)           { values.push(station_id);          conditions.push(`p.station_id = $${values.length}`); }
    if (availability_status)  { values.push(availability_status);  conditions.push(`p.availability_status = $${values.length}`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await pool.query(
      `SELECT p.*, u.name, u.phone, s.station_name
       FROM porters p
       JOIN users u ON p.user_id = u.user_id
       JOIN stations s ON p.station_id = s.station_id
       ${where}
       ORDER BY p.porter_id`,
      values
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getPorterById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT p.*, u.name, u.phone, s.station_name
       FROM porters p
       JOIN users u ON p.user_id = u.user_id
       JOIN stations s ON p.station_id = s.station_id
       WHERE p.porter_id = $1`,
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Porter not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Uses COALESCE so a partial update (e.g. just toggling availability_status
// from the porter's own dashboard) doesn't null out the other columns.
exports.updatePorter = async (req, res) => {
  try {
    const { id } = req.params;
    const { availability_status, current_platform_id, rating } = req.body;
    const result = await pool.query(
      `UPDATE porters SET availability_status = COALESCE($1, availability_status),
                           current_platform_id = COALESCE($2, current_platform_id),
                           rating = COALESCE($3, rating)
       WHERE porter_id = $4 RETURNING *`,
      [availability_status, current_platform_id, rating, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Porter not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deletePorter = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM porters WHERE porter_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Porter not found' });
    res.json({ message: 'Porter deleted', porter: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
