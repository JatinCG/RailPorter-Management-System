const pool = require('../config/db');

exports.createPayment = async (req, res) => {
  try {
    const { booking_id, amount, payment_method, transaction_id } = req.body;
    const result = await pool.query(
      `INSERT INTO payments (booking_id, amount, payment_method, payment_status, transaction_id)
       VALUES ($1, $2, $3, 'PENDING', $4) RETURNING *`,
      [booking_id, amount, payment_method, transaction_id || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Optional filter: /api/payments?booking_id=3
exports.getPayments = async (req, res) => {
  try {
    const { booking_id } = req.query;
    const conditions = [];
    const values = [];
    if (booking_id) { values.push(booking_id); conditions.push(`pay.booking_id = $${values.length}`); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await pool.query(
      `SELECT pay.*, b.train_number, b.destination
       FROM payments pay
       JOIN bookings b ON pay.booking_id = b.booking_id
       ${where}
       ORDER BY pay.payment_id DESC`,
      values
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getPaymentById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM payments WHERE payment_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payment not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updatePayment = async (req, res) => {
  try {
    const { id } = req.params;
    const { payment_status, transaction_id } = req.body;
    const result = await pool.query(
      `UPDATE payments SET payment_status = COALESCE($1, payment_status),
                            transaction_id = COALESCE($2, transaction_id)
       WHERE payment_id = $3 RETURNING *`,
      [payment_status, transaction_id, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payment not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deletePayment = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM payments WHERE payment_id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payment not found' });
    res.json({ message: 'Payment deleted', payment: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
