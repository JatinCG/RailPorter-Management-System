-- ============================================
-- RailPort Database Schema (PostgreSQL)
-- Run this AFTER: CREATE DATABASE railport_db;
-- Order matters: tables are created in dependency order
-- ============================================

-- 1. USERS (base table for passengers, porters, admins)
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL
        CHECK (role IN ('PASSENGER', 'PORTER', 'ADMIN')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. STATIONS
CREATE TABLE stations (
    station_id SERIAL PRIMARY KEY,
    station_name VARCHAR(100) NOT NULL,
    station_code VARCHAR(10) NOT NULL UNIQUE,
    city VARCHAR(100) NOT NULL,
    number_of_platforms INT NOT NULL
        CHECK (number_of_platforms > 0)
);

-- 3. PLATFORMS (depends on stations)
CREATE TABLE platforms (
    platform_id SERIAL PRIMARY KEY,
    station_id INT NOT NULL,
    platform_number INT NOT NULL
        CHECK (platform_number > 0),
    FOREIGN KEY (station_id)
        REFERENCES stations(station_id)
        ON DELETE CASCADE,
    UNIQUE (station_id, platform_number)
);

-- 4. PORTERS (depends on users, stations, platforms)
CREATE TABLE porters (
    porter_id SERIAL PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    station_id INT NOT NULL,
    badge_number VARCHAR(50) NOT NULL UNIQUE,
    availability_status VARCHAR(20) NOT NULL DEFAULT 'OFFLINE'
        CHECK (availability_status IN ('AVAILABLE', 'BUSY', 'OFFLINE')),
    current_platform_id INT,
    rating NUMERIC(3,2) DEFAULT 0.00
        CHECK (rating >= 0 AND rating <= 5),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (station_id) REFERENCES stations(station_id),
    FOREIGN KEY (current_platform_id) REFERENCES platforms(platform_id)
);

-- 5. BOOKINGS (depends on users, porters, stations, platforms)
CREATE TABLE bookings (
    booking_id SERIAL PRIMARY KEY,
    passenger_id INT NOT NULL,
    porter_id INT,
    station_id INT NOT NULL,
    pickup_platform_id INT,
    train_number VARCHAR(20),
    coach_number VARCHAR(20),
    luggage_count INT NOT NULL DEFAULT 1
        CHECK (luggage_count > 0),
    destination VARCHAR(255),
    fare NUMERIC(10,2) NOT NULL DEFAULT 0.00
        CHECK (fare >= 0),
    status VARCHAR(20) NOT NULL DEFAULT 'REQUESTED'
        CHECK (status IN ('REQUESTED', 'ACCEPTED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (passenger_id) REFERENCES users(user_id),
    FOREIGN KEY (porter_id) REFERENCES porters(porter_id),
    FOREIGN KEY (station_id) REFERENCES stations(station_id),
    FOREIGN KEY (pickup_platform_id) REFERENCES platforms(platform_id)
);

-- 6. PAYMENTS (depends on bookings)
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    amount NUMERIC(10,2) NOT NULL
        CHECK (amount >= 0),
    payment_method VARCHAR(20) NOT NULL
        CHECK (payment_method IN ('CASH', 'UPI', 'CARD')),
    payment_status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
        CHECK (payment_status IN ('PENDING', 'SUCCESS', 'FAILED')),
    transaction_id VARCHAR(100),
    payment_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- 7. RATINGS (depends on bookings, users, porters)
CREATE TABLE ratings (
    rating_id SERIAL PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    passenger_id INT NOT NULL,
    porter_id INT NOT NULL,
    stars INT NOT NULL
        CHECK (stars BETWEEN 1 AND 5),
    review VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (passenger_id) REFERENCES users(user_id),
    FOREIGN KEY (porter_id) REFERENCES porters(porter_id)
);

-- Helpful indexes for common lookups (used heavily once CRUD/API is running)
CREATE INDEX idx_bookings_passenger ON bookings(passenger_id);
CREATE INDEX idx_bookings_porter ON bookings(porter_id);
CREATE INDEX idx_bookings_station ON bookings(station_id);
CREATE INDEX idx_porters_station ON porters(station_id);
CREATE INDEX idx_platforms_station ON platforms(station_id);
