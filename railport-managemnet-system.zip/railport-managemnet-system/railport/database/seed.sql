-- ============================================
-- RailPort Sample Data
-- Run this AFTER schema.sql
-- ============================================

-- STATIONS
INSERT INTO stations (station_name, station_code, city, number_of_platforms) VALUES
('Chennai Central', 'MAS', 'Chennai', 12),
('Chennai Egmore', 'MS', 'Chennai', 10),
('Coimbatore Junction', 'CBE', 'Coimbatore', 6);

-- PLATFORMS
INSERT INTO platforms (station_id, platform_number) VALUES
(1,1),(1,2),(1,3),(1,4),(1,5),
(2,1),(2,2),(2,3),
(3,1),(3,2),(3,3);

-- USERS (passengers, porters, admin)
-- Password for every seeded account is: password123
-- (bcrypt hash below is real, so you can actually log in with these during a demo)
INSERT INTO users (name, phone, email, password, role) VALUES
('Rahul Kumar', '9876543210', 'rahul@example.com', '$2a$10$HXvmuzYvQxM7IBA8V/ezxed9dTkfZGsZSf//RKtJ/gdtXl2nK4C6y', 'PASSENGER'),
('Priya Sharma', '9876543213', 'priya@example.com', '$2a$10$HXvmuzYvQxM7IBA8V/ezxed9dTkfZGsZSf//RKtJ/gdtXl2nK4C6y', 'PASSENGER'),
('Arun Kumar', '9876543211', 'arun@example.com', '$2a$10$HXvmuzYvQxM7IBA8V/ezxed9dTkfZGsZSf//RKtJ/gdtXl2nK4C6y', 'PORTER'),
('Selvam R', '9876543214', 'selvam@example.com', '$2a$10$HXvmuzYvQxM7IBA8V/ezxed9dTkfZGsZSf//RKtJ/gdtXl2nK4C6y', 'PORTER'),
('Admin User', '9876543212', 'admin@example.com', '$2a$10$HXvmuzYvQxM7IBA8V/ezxed9dTkfZGsZSf//RKtJ/gdtXl2nK4C6y', 'ADMIN');

-- PORTERS (linked to users with role PORTER)
INSERT INTO porters (user_id, station_id, badge_number, availability_status, current_platform_id, rating) VALUES
(3, 1, 'MAS-P001', 'AVAILABLE', 1, 4.50),
(4, 1, 'MAS-P002', 'BUSY', 2, 4.20);

-- BOOKINGS
INSERT INTO bookings (passenger_id, porter_id, station_id, pickup_platform_id, train_number, coach_number, luggage_count, destination, fare, status) VALUES
(1, 1, 1, 1, '12621', 'S5', 3, 'Main Exit', 150.00, 'COMPLETED'),
(2, 2, 1, 2, '12658', 'A1', 2, 'Parking Lot', 120.00, 'IN_PROGRESS');

-- PAYMENTS (only for completed booking)
INSERT INTO payments (booking_id, amount, payment_method, payment_status, transaction_id) VALUES
(1, 150.00, 'UPI', 'SUCCESS', 'TXN1001');

-- RATINGS (only for completed booking)
INSERT INTO ratings (booking_id, passenger_id, porter_id, stars, review) VALUES
(1, 1, 1, 5, 'Very helpful and quick service.');
