import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
});

// Generic CRUD helpers — reused by every entity page via EntityCRUD.jsx
// `params` is optional: e.g. getAll('bookings', { passenger_id: 3 }) hits
// GET /api/bookings?passenger_id=3, using the filters the controllers support.
export const getAll = (resource, params) => api.get(`/${resource}`, { params });
export const getOne = (resource, id) => api.get(`/${resource}/${id}`);
export const createOne = (resource, data) => api.post(`/${resource}`, data);
export const updateOne = (resource, id, data) => api.put(`/${resource}/${id}`, data);
export const deleteOne = (resource, id) => api.delete(`/${resource}/${id}`);

// Auth
export const authRegister = (data) => api.post('/auth/register', data);
export const authLogin = (data) => api.post('/auth/login', data);

export default api;
