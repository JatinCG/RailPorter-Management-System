import React, { useEffect, useState } from 'react';
import { authLogin, authRegister, getAll } from '../services/api';

const emptyRegister = {
  name: '', phone: '', email: '', password: '',
  role: 'PASSENGER', station_id: '', badge_number: '',
};

export default function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [loginForm, setLoginForm] = useState({ phone: '', password: '' });
  const [registerForm, setRegisterForm] = useState(emptyRegister);
  const [stations, setStations] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Needed so a registering porter can pick a real station_id.
    getAll('stations').then((res) => setStations(res.data)).catch(() => {});
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await authLogin(loginForm);
      onAuthenticated(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const payload = { ...registerForm };
      if (payload.role !== 'PORTER') {
        delete payload.station_id;
        delete payload.badge_number;
      }
      const res = await authRegister(payload);
      // Registration doesn't return a password, so log in right after
      // to get the same session shape login produces.
      const loginRes = await authLogin({ phone: payload.phone, password: payload.password });
      onAuthenticated(loginRes.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <h1>RailPort</h1>
        <p className="auth-subtitle">On-demand porter booking for railway stations</p>

        <div className="auth-toggle">
          <button
            className={mode === 'login' ? 'tab active' : 'tab'}
            onClick={() => { setMode('login'); setError(''); }}
          >
            Log in
          </button>
          <button
            className={mode === 'register' ? 'tab active' : 'tab'}
            onClick={() => { setMode('register'); setError(''); }}
          >
            Register
          </button>
        </div>

        {error && <p className="error">{error}</p>}

        {mode === 'login' ? (
          <form className="auth-form" onSubmit={handleLogin}>
            <label className="form-field">
              <span>Phone</span>
              <input
                type="text" required value={loginForm.phone}
                onChange={(e) => setLoginForm({ ...loginForm, phone: e.target.value })}
              />
            </label>
            <label className="form-field">
              <span>Password</span>
              <input
                type="password" required value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
              />
            </label>
            <button type="submit" disabled={loading}>{loading ? 'Logging in...' : 'Log in'}</button>
            <p className="auth-hint">
              Seeded demo accounts (password: password123):<br />
              Passenger — 9876543210 · Porter — 9876543211 · Admin — 9876543212
            </p>
          </form>
        ) : (
          <form className="auth-form" onSubmit={handleRegister}>
            <label className="form-field">
              <span>I am a</span>
              <select
                value={registerForm.role}
                onChange={(e) => setRegisterForm({ ...registerForm, role: e.target.value })}
              >
                <option value="PASSENGER">Passenger</option>
                <option value="PORTER">Porter</option>
              </select>
            </label>
            <label className="form-field">
              <span>Name</span>
              <input
                type="text" required value={registerForm.name}
                onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
              />
            </label>
            <label className="form-field">
              <span>Phone</span>
              <input
                type="text" required value={registerForm.phone}
                onChange={(e) => setRegisterForm({ ...registerForm, phone: e.target.value })}
              />
            </label>
            <label className="form-field">
              <span>Email (optional)</span>
              <input
                type="email" value={registerForm.email}
                onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
              />
            </label>
            <label className="form-field">
              <span>Password</span>
              <input
                type="password" required value={registerForm.password}
                onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
              />
            </label>

            {registerForm.role === 'PORTER' && (
              <>
                <label className="form-field">
                  <span>Home station</span>
                  <select
                    required value={registerForm.station_id}
                    onChange={(e) => setRegisterForm({ ...registerForm, station_id: e.target.value })}
                  >
                    <option value="" disabled>Select a station...</option>
                    {stations.map((s) => (
                      <option key={s.station_id} value={s.station_id}>{s.station_name}</option>
                    ))}
                  </select>
                </label>
                <label className="form-field">
                  <span>Badge number</span>
                  <input
                    type="text" required value={registerForm.badge_number}
                    onChange={(e) => setRegisterForm({ ...registerForm, badge_number: e.target.value })}
                  />
                </label>
              </>
            )}

            <button type="submit" disabled={loading}>{loading ? 'Creating account...' : 'Register'}</button>
          </form>
        )}
      </div>
    </div>
  );
}
