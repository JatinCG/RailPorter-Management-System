import React, { useEffect, useMemo, useState } from 'react';
import { getAll, createOne, updateOne } from '../services/api';

const BASE_FARE = 50;
const FARE_PER_BAG = 20;

function estimateFare(luggageCount) {
  const n = Number(luggageCount) || 1;
  return BASE_FARE + n * FARE_PER_BAG;
}

const emptyBookingForm = {
  station_id: '', pickup_platform_id: '', train_number: '',
  coach_number: '', luggage_count: 1, destination: '',
};

export default function PassengerDashboard({ session, onLogout }) {
  const [tab, setTab] = useState('book');

  const [stations, setStations] = useState([]);
  const [platforms, setPlatforms] = useState([]);
  const [form, setForm] = useState(emptyBookingForm);
  const [bookError, setBookError] = useState('');
  const [creating, setCreating] = useState(false);

  const [bookings, setBookings] = useState([]);
  const [payments, setPayments] = useState([]);
  const [ratings, setRatings] = useState([]);
  const [loadingBookings, setLoadingBookings] = useState(false);

  // per-booking inline form state
  const [payOpenFor, setPayOpenFor] = useState(null);
  const [payMethod, setPayMethod] = useState('UPI');
  const [rateOpenFor, setRateOpenFor] = useState(null);
  const [rateStars, setRateStars] = useState(5);
  const [rateReview, setRateReview] = useState('');
  const [actionError, setActionError] = useState('');

  const passengerId = session.user.user_id;

  useEffect(() => {
    getAll('stations').then((res) => setStations(res.data)).catch(() => {});
    getAll('platforms').then((res) => setPlatforms(res.data)).catch(() => {});
  }, []);

  const loadMyStuff = async () => {
    setLoadingBookings(true);
    try {
      const [bRes, payRes, ratRes] = await Promise.all([
        getAll('bookings', { passenger_id: passengerId }),
        getAll('payments'),
        getAll('ratings', { passenger_id: passengerId }),
      ]);
      setBookings(bRes.data);
      setPayments(payRes.data);
      setRatings(ratRes.data);
    } catch (err) {
      setActionError(err.response?.data?.error || err.message);
    } finally {
      setLoadingBookings(false);
    }
  };

  useEffect(() => {
    if (tab === 'mybookings') loadMyStuff();
  }, [tab]);

  const platformsForStation = useMemo(
    () => platforms.filter((p) => String(p.station_id) === String(form.station_id)),
    [platforms, form.station_id]
  );

  const paymentByBooking = useMemo(() => {
    const map = {};
    payments.forEach((p) => { map[p.booking_id] = p; });
    return map;
  }, [payments]);

  const ratingByBooking = useMemo(() => {
    const map = {};
    ratings.forEach((r) => { map[r.booking_id] = r; });
    return map;
  }, [ratings]);

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    setBookError('');
    setCreating(true);
    try {
      await createOne('bookings', {
        passenger_id: passengerId,
        station_id: form.station_id,
        pickup_platform_id: form.pickup_platform_id || null,
        train_number: form.train_number,
        coach_number: form.coach_number,
        luggage_count: form.luggage_count,
        destination: form.destination,
        fare: estimateFare(form.luggage_count),
      });
      setForm(emptyBookingForm);
      setTab('mybookings');
    } catch (err) {
      setBookError(err.response?.data?.error || err.message);
    } finally {
      setCreating(false);
    }
  };

  const cancelBooking = async (bookingId) => {
    setActionError('');
    try {
      await updateOne('bookings', bookingId, { status: 'CANCELLED' });
      loadMyStuff();
    } catch (err) {
      setActionError(err.response?.data?.error || err.message);
    }
  };

  const submitPayment = async (booking) => {
    setActionError('');
    try {
      const created = await createOne('payments', {
        booking_id: booking.booking_id,
        amount: booking.fare,
        payment_method: payMethod,
      });
      // Simulated gateway: mark it successful immediately.
      await updateOne('payments', created.data.payment_id, { payment_status: 'SUCCESS' });
      setPayOpenFor(null);
      loadMyStuff();
    } catch (err) {
      setActionError(err.response?.data?.error || err.message);
    }
  };

  const submitRating = async (booking) => {
    setActionError('');
    try {
      await createOne('ratings', {
        booking_id: booking.booking_id,
        passenger_id: passengerId,
        porter_id: booking.porter_id,
        stars: rateStars,
        review: rateReview,
      });
      setRateOpenFor(null);
      setRateReview('');
      setRateStars(5);
      loadMyStuff();
    } catch (err) {
      setActionError(err.response?.data?.error || err.message);
    }
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-row">
          <div>
            <h1>RailPort</h1>
            <p>Hi {session.user.name} — book a porter for your next trip</p>
          </div>
          <button className="secondary" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <nav className="tabs">
        <button className={tab === 'book' ? 'tab active' : 'tab'} onClick={() => setTab('book')}>
          Book a Porter
        </button>
        <button className={tab === 'mybookings' ? 'tab active' : 'tab'} onClick={() => setTab('mybookings')}>
          My Bookings
        </button>
      </nav>

      <main>
        {tab === 'book' && (
          <div className="entity-panel">
            <h2>Book a porter</h2>
            <form className="entity-form" onSubmit={handleBookingSubmit}>
              <label className="form-field">
                <span>Station</span>
                <select
                  required value={form.station_id}
                  onChange={(e) => setForm({ ...form, station_id: e.target.value, pickup_platform_id: '' })}
                >
                  <option value="" disabled>Select a station...</option>
                  {stations.map((s) => (
                    <option key={s.station_id} value={s.station_id}>{s.station_name}</option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Platform</span>
                <select
                  value={form.pickup_platform_id}
                  onChange={(e) => setForm({ ...form, pickup_platform_id: e.target.value })}
                  disabled={!form.station_id}
                >
                  <option value="">Not sure yet</option>
                  {platformsForStation.map((p) => (
                    <option key={p.platform_id} value={p.platform_id}>Platform {p.platform_number}</option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Train number</span>
                <input
                  type="text" required value={form.train_number}
                  onChange={(e) => setForm({ ...form, train_number: e.target.value })}
                />
              </label>
              <label className="form-field">
                <span>Coach number</span>
                <input
                  type="text" value={form.coach_number}
                  onChange={(e) => setForm({ ...form, coach_number: e.target.value })}
                />
              </label>
              <label className="form-field">
                <span>Number of bags</span>
                <input
                  type="number" min="1" required value={form.luggage_count}
                  onChange={(e) => setForm({ ...form, luggage_count: e.target.value })}
                />
              </label>
              <label className="form-field">
                <span>Destination (within/outside station)</span>
                <input
                  type="text" required value={form.destination}
                  onChange={(e) => setForm({ ...form, destination: e.target.value })}
                />
              </label>
              <div className="form-actions" style={{ alignItems: 'center', gap: 16 }}>
                <span className="fare-estimate">Estimated fare: ₹{estimateFare(form.luggage_count)}</span>
                <button type="submit" disabled={creating}>{creating ? 'Booking...' : 'Book Porter'}</button>
              </div>
            </form>
            {bookError && <p className="error">{bookError}</p>}
          </div>
        )}

        {tab === 'mybookings' && (
          <div className="entity-panel">
            <h2>My bookings</h2>
            {actionError && <p className="error">{actionError}</p>}
            {loadingBookings ? (
              <p>Loading...</p>
            ) : bookings.length === 0 ? (
              <p>You haven't booked a porter yet.</p>
            ) : (
              <div className="card-list">
                {bookings.map((b) => {
                  const payment = paymentByBooking[b.booking_id];
                  const rating = ratingByBooking[b.booking_id];
                  return (
                    <div className="booking-card" key={b.booking_id}>
                      <div className="booking-card-head">
                        <strong>Booking #{b.booking_id}</strong>
                        <span className={`status-badge status-${b.status.toLowerCase()}`}>{b.status}</span>
                      </div>
                      <p>{b.station_name} {b.platform_number ? `· Platform ${b.platform_number}` : ''}</p>
                      <p>Train {b.train_number} {b.coach_number ? `· Coach ${b.coach_number}` : ''} · {b.luggage_count} bag(s)</p>
                      <p>To: {b.destination}</p>
                      <p>Porter: {b.porter_name || 'Not assigned yet'}</p>
                      <p>Fare: ₹{b.fare}</p>

                      <div className="booking-card-actions">
                        {b.status === 'REQUESTED' && (
                          <button className="danger" onClick={() => cancelBooking(b.booking_id)}>Cancel</button>
                        )}
                        {b.porter_id && !payment && (
                          <button onClick={() => setPayOpenFor(payOpenFor === b.booking_id ? null : b.booking_id)}>
                            Pay
                          </button>
                        )}
                        {payment && <span className="paid-tag">Paid via {payment.payment_method}</span>}
                        {b.status === 'COMPLETED' && !rating && (
                          <button onClick={() => setRateOpenFor(rateOpenFor === b.booking_id ? null : b.booking_id)}>
                            Rate porter
                          </button>
                        )}
                        {rating && <span className="paid-tag">You rated {rating.stars}★</span>}
                      </div>

                      {payOpenFor === b.booking_id && (
                        <div className="inline-form">
                          <label className="form-field">
                            <span>Payment method</span>
                            <select value={payMethod} onChange={(e) => setPayMethod(e.target.value)}>
                              <option value="UPI">UPI</option>
                              <option value="CARD">Card</option>
                              <option value="CASH">Cash</option>
                            </select>
                          </label>
                          <button onClick={() => submitPayment(b)}>Pay ₹{b.fare} (simulated)</button>
                        </div>
                      )}

                      {rateOpenFor === b.booking_id && (
                        <div className="inline-form">
                          <label className="form-field">
                            <span>Stars</span>
                            <select value={rateStars} onChange={(e) => setRateStars(Number(e.target.value))}>
                              {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} star{n > 1 ? 's' : ''}</option>)}
                            </select>
                          </label>
                          <label className="form-field">
                            <span>Review</span>
                            <input type="text" value={rateReview} onChange={(e) => setRateReview(e.target.value)} />
                          </label>
                          <button onClick={() => submitRating(b)}>Submit rating</button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
