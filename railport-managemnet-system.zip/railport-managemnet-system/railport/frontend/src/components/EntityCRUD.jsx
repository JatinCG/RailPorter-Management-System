import React, { useEffect, useState } from 'react';
import { getAll, createOne, updateOne, deleteOne } from '../services/api';

function emptyForm(fields) {
  const obj = {};
  fields.forEach((f) => (obj[f.name] = ''));
  return obj;
}

export default function EntityCRUD({ config }) {
  const { label, resource, idField, fields } = config;

  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(emptyForm(fields));
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadRows = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAll(resource);
      setRows(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRows();
    setForm(emptyForm(fields));
    setEditingId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resource]);

  const handleChange = (name, value) => {
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editingId) {
        await updateOne(resource, editingId, form);
      } else {
        await createOne(resource, form);
      }
      setForm(emptyForm(fields));
      setEditingId(null);
      loadRows();
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  const handleEdit = (row) => {
    const next = emptyForm(fields);
    fields.forEach((f) => {
      if (!f.createOnly) next[f.name] = row[f.name] ?? '';
    });
    setForm(next);
    setEditingId(row[idField]);
  };

  const handleCancelEdit = () => {
    setForm(emptyForm(fields));
    setEditingId(null);
  };

  const handleDelete = async (id) => {
    if (!window.confirm(`Delete ${label.slice(0, -1)} #${id}?`)) return;
    setError('');
    try {
      await deleteOne(resource, id);
      loadRows();
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  // Table columns come from whatever the API actually returns for the first row,
  // so joined fields (like station_name) show up automatically.
  const columns = rows.length > 0 ? Object.keys(rows[0]) : [idField, ...fields.map((f) => f.name)];

  return (
    <div className="entity-panel">
      <h2>{label}</h2>

      <form className="entity-form" onSubmit={handleSubmit}>
        {fields.map((f) => {
          if (editingId && f.createOnly) return null;
          return (
            <label key={f.name} className="form-field">
              <span>{f.label}</span>
              {f.type === 'select' ? (
                <select
                  value={form[f.name] ?? ''}
                  onChange={(e) => handleChange(f.name, e.target.value)}
                  required
                >
                  <option value="" disabled>
                    Select...
                  </option>
                  {f.options.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type={f.type}
                  step={f.step}
                  value={form[f.name] ?? ''}
                  onChange={(e) => handleChange(f.name, e.target.value)}
                  required={f.type !== 'password' || !editingId}
                />
              )}
            </label>
          );
        })}
        <div className="form-actions">
          <button type="submit">{editingId ? 'Update' : 'Create'}</button>
          {editingId && (
            <button type="button" className="secondary" onClick={handleCancelEdit}>
              Cancel
            </button>
          )}
        </div>
      </form>

      {error && <p className="error">{error}</p>}
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table className="entity-table">
          <thead>
            <tr>
              {columns.map((c) => (
                <th key={c}>{c}</th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row[idField]}>
                {columns.map((c) => (
                  <td key={c}>{String(row[c] ?? '')}</td>
                ))}
                <td className="row-actions">
                  <button onClick={() => handleEdit(row)}>Edit</button>
                  <button className="danger" onClick={() => handleDelete(row[idField])}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={columns.length + 1}>No records yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}
