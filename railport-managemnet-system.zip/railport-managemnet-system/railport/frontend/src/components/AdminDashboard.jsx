import React, { useState } from 'react';
import EntityCRUD from './EntityCRUD.jsx';
import { entities, entityOrder } from '../config/entities.js';

export default function AdminDashboard({ session, onLogout }) {
  const [active, setActive] = useState(entityOrder[0]);

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-row">
          <div>
            <h1>RailPort Admin</h1>
            <p>Signed in as {session.user.name} — full CRUD console</p>
          </div>
          <button className="secondary" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <nav className="tabs">
        {entityOrder.map((key) => (
          <button
            key={key}
            className={key === active ? 'tab active' : 'tab'}
            onClick={() => setActive(key)}
          >
            {entities[key].label}
          </button>
        ))}
      </nav>

      <main>
        <EntityCRUD config={entities[active]} />
      </main>
    </div>
  );
}
