import React, { useEffect, useMemo, useState } from 'react';
import { getAll, updateOne } from '../services/api';

export default function PorterDashboard({ session, onLogout }) {
  const [porter, setPorter] = useState(session.porter);
  const [tab, setTab] = useState('available');

  const [available, setAvailable] = useState([]);
  const [mine, setMine] = useState([]);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadAvailable = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAll('bookings', {
        station_id: porter.station_id, status: 'REQUESTED', unassigned: 'true',
      });
      setAvailable(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadMine = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAll('bookings', { porter_id: porter.porter_id });
      setMine(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadRatings = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getAll('ratings', { porter_id: porter.porter_id });
      setRatings(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tab === 'available') loadAvailable();
    if (tab === 'mine') loadMine();
    if (tab === 'ratings') loadRatings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const averageRating = useMemo(() => {
    if (ratings.length === 0) return null;
    return (ratings.reduce((sum, r) => sum + r.stars, 0) / ratings.length).toFixed(1);
  }, [ratings]);

  const setAvailability = async (status) => {
    setError('');
    try {
      const res = await updateOne('porters', porter.porter_id, { availability_status: status });
      setPorter({ ...porter, availability_status: res.data.availability_status });
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  const acceptBooking = async (bookingId) => {
    setError('');
    try {
      await updateOne('bookings', bookingId, { porter_id: porter.porter_id, status: 'ACCEPTED' });
      await setAvailability('BUSY');
      loadAvailable();
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  const advanceBooking = async (booking, nextStatus) => {
    setError('');
    try {
      const payload = { status: nextStatus };
      if (nextStatus === 'COMPLETED') payload.completed_at = new Date().toISOString();
      await updateOne('bookings', booking.booking_id, payload);
      if (nextStatus === 'COMPLETED' || nextStatus === 'CANCELLED') {
        await setAvailability('AVAILABLE');
      }
      loadMine();
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-row">
          <div>
            <h1>RailPort — Porter</h1>
            <p>{session.user.name} · Badge {porter.badge_number}</p>
          </div>
          <button className="secondary" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <div className="availability-bar">
        <span>Availability:</span>
        {['AVAILABLE', 'BUSY', 'OFFLINE'].map((s) => (
          <button
            key={s}
            className={porter.availability_status === s ? 'tab active' : 'tab'}
            onClick={() => setAvailability(s)}
          >
            {s}
          </button>
        ))}
      </div>

      <nav className="tabs">
        <button className={tab === 'available' ? 'tab active' : 'tab'} onClick={() => setTab('available')}>
          Available Requests
        </button>
        <button className={tab === 'mine' ? 'tab active' : 'tab'} onClick={() => setTab('mine')}>
          My Bookings
        </button>
        <button className={tab === 'ratings' ? 'tab active' : 'tab'} onClick={() => setTab('ratings')}>
          My Ratings {averageRating ? `(${averageRating}★ avg)` : ''}
        </button>
      </nav>

      <main>
        {error && <p className="error">{error}</p>}

        {tab === 'available' && (
          <div className="entity-panel">
            <h2>Open requests at your station</h2>
            {loading ? <p>Loading...</p> : available.length === 0 ? (
              <p>No unassigned requests right now.</p>
            ) : (
              <div className="card-list">
                {available.map((b) => (
                  <div className="booking-card" key={b.booking_id}>
                    <div className="booking-card-head">
                      <strong>Booking #{b.booking_id}</strong>
                      <span className="status-badge status-requested">{b.status}</span>
                    </div>
                    <p>{b.station_name} {b.platform_number ? `· Platform ${b.platform_number}` : ''}</p>
                    <p>Passenger: {b.passenger_name}</p>
                    <p>Train {b.train_number} · {b.luggage_count} bag(s) · To: {b.destination}</p>
                    <p>Fare: ₹{b.fare}</p>
                    <div className="booking-card-actions">
                      <button onClick={() => acceptBooking(b.booking_id)}>Accept</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'mine' && (
          <div className="entity-panel">
            <h2>My assigned bookings</h2>
            {loading ? <p>Loading...</p> : mine.length === 0 ? (
              <p>No bookings assigned to you yet.</p>
            ) : (
              <div className="card-list">
                {mine.map((b) => (
                  <div className="booking-card" key={b.booking_id}>
                    <div className="booking-card-head">
                      <strong>Booking #{b.booking_id}</strong>
                      <span className={`status-badge status-${b.status.toLowerCase()}`}>{b.status}</span>
                    </div>
                    <p>{b.station_name} {b.platform_number ? `· Platform ${b.platform_number}` : ''}</p>
                    <p>Passenger: {b.passenger_name}</p>
                    <p>Train {b.train_number} · {b.luggage_count} bag(s) · To: {b.destination}</p>
                    <p>Fare: ₹{b.fare}</p>
                    <div className="booking-card-actions">
                      {b.status === 'ACCEPTED' && (
                        <button onClick={() => advanceBooking(b, 'IN_PROGRESS')}>Start</button>
                      )}
                      {b.status === 'IN_PROGRESS' && (
                        <button onClick={() => advanceBooking(b, 'COMPLETED')}>Complete</button>
                      )}
                      {(b.status === 'ACCEPTED' || b.status === 'IN_PROGRESS') && (
                        <button className="danger" onClick={() => advanceBooking(b, 'CANCELLED')}>Cancel</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'ratings' && (
          <div className="entity-panel">
            <h2>Ratings you've received</h2>
            {loading ? <p>Loading...</p> : ratings.length === 0 ? (
              <p>No ratings yet.</p>
            ) : (
              <div className="card-list">
                {ratings.map((r) => (
                  <div className="booking-card" key={r.rating_id}>
                    <div className="booking-card-head">
                      <strong>{r.passenger_name}</strong>
                      <span className="status-badge status-completed">{r.stars}★</span>
                    </div>
                    {r.review && <p>&ldquo;{r.review}&rdquo;</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
