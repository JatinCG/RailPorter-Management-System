import React, { useEffect, useState } from 'react';
import AuthScreen from './components/AuthScreen.jsx';
import PassengerDashboard from './components/PassengerDashboard.jsx';
import PorterDashboard from './components/PorterDashboard.jsx';
import AdminDashboard from './components/AdminDashboard.jsx';

const SESSION_KEY = 'railport_session';

export default function App() {
  const [session, setSession] = useState(null);
  const [ready, setReady] = useState(false);

  // Restore session on page reload so logging in isn't needed every time.
  useEffect(() => {
    try {
      const stored = localStorage.getItem(SESSION_KEY);
      if (stored) setSession(JSON.parse(stored));
    } catch {
      // ignore corrupted storage
    } finally {
      setReady(true);
    }
  }, []);

  const handleAuthenticated = (data) => {
    setSession(data);
    localStorage.setItem(SESSION_KEY, JSON.stringify(data));
  };

  const handleLogout = () => {
    setSession(null);
    localStorage.removeItem(SESSION_KEY);
  };

  if (!ready) return null;

  if (!session) {
    return <AuthScreen onAuthenticated={handleAuthenticated} />;
  }

  switch (session.user.role) {
    case 'PASSENGER':
      return <PassengerDashboard session={session} onLogout={handleLogout} />;
    case 'PORTER':
      return <PorterDashboard session={session} onLogout={handleLogout} />;
    case 'ADMIN':
      return <AdminDashboard session={session} onLogout={handleLogout} />;
    default:
      return <AuthScreen onAuthenticated={handleAuthenticated} />;
  }
}
