// Each entity config tells the generic EntityCRUD component:
// - resource: API path segment (matches backend routes, e.g. /api/stations)
// - idField: primary key name returned by the API
// - fields: form fields shown for create/edit, in order

export const entities = {
  users: {
    label: 'Users',
    resource: 'users',
    idField: 'user_id',
    fields: [
      { name: 'name', label: 'Name', type: 'text' },
      { name: 'phone', label: 'Phone', type: 'text' },
      { name: 'email', label: 'Email', type: 'email' },
      { name: 'password', label: 'Password', type: 'password', createOnly: true },
      {
        name: 'role', label: 'Role', type: 'select',
        options: ['PASSENGER', 'PORTER', 'ADMIN'],
      },
    ],
  },

  stations: {
    label: 'Stations',
    resource: 'stations',
    idField: 'station_id',
    fields: [
      { name: 'station_name', label: 'Station Name', type: 'text' },
      { name: 'station_code', label: 'Station Code', type: 'text' },
      { name: 'city', label: 'City', type: 'text' },
      { name: 'number_of_platforms', label: 'No. of Platforms', type: 'number' },
    ],
  },

  platforms: {
    label: 'Platforms',
    resource: 'platforms',
    idField: 'platform_id',
    fields: [
      { name: 'station_id', label: 'Station ID', type: 'number' },
      { name: 'platform_number', label: 'Platform Number', type: 'number' },
    ],
  },

  porters: {
    label: 'Porters',
    resource: 'porters',
    idField: 'porter_id',
    fields: [
      { name: 'user_id', label: 'User ID', type: 'number' },
      { name: 'station_id', label: 'Station ID', type: 'number' },
      { name: 'badge_number', label: 'Badge Number', type: 'text' },
      {
        name: 'availability_status', label: 'Availability', type: 'select',
        options: ['AVAILABLE', 'BUSY', 'OFFLINE'],
      },
      { name: 'current_platform_id', label: 'Current Platform ID', type: 'number' },
      { name: 'rating', label: 'Rating', type: 'number', step: '0.01' },
    ],
  },

  bookings: {
    label: 'Bookings',
    resource: 'bookings',
    idField: 'booking_id',
    fields: [
      { name: 'passenger_id', label: 'Passenger ID', type: 'number' },
      { name: 'porter_id', label: 'Porter ID', type: 'number' },
      { name: 'station_id', label: 'Station ID', type: 'number' },
      { name: 'pickup_platform_id', label: 'Pickup Platform ID', type: 'number' },
      { name: 'train_number', label: 'Train Number', type: 'text' },
      { name: 'coach_number', label: 'Coach Number', type: 'text' },
      { name: 'luggage_count', label: 'Luggage Count', type: 'number' },
      { name: 'destination', label: 'Destination', type: 'text' },
      { name: 'fare', label: 'Fare', type: 'number', step: '0.01' },
      {
        name: 'status', label: 'Status', type: 'select',
        options: ['REQUESTED', 'ACCEPTED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
      },
    ],
  },

  payments: {
    label: 'Payments',
    resource: 'payments',
    idField: 'payment_id',
    fields: [
      { name: 'booking_id', label: 'Booking ID', type: 'number' },
      { name: 'amount', label: 'Amount', type: 'number', step: '0.01' },
      {
        name: 'payment_method', label: 'Payment Method', type: 'select',
        options: ['CASH', 'UPI', 'CARD'],
      },
      {
        name: 'payment_status', label: 'Payment Status', type: 'select',
        options: ['PENDING', 'SUCCESS', 'FAILED'],
      },
      { name: 'transaction_id', label: 'Transaction ID', type: 'text' },
    ],
  },

  ratings: {
    label: 'Ratings',
    resource: 'ratings',
    idField: 'rating_id',
    fields: [
      { name: 'booking_id', label: 'Booking ID', type: 'number' },
      { name: 'passenger_id', label: 'Passenger ID', type: 'number' },
      { name: 'porter_id', label: 'Porter ID', type: 'number' },
      { name: 'stars', label: 'Stars (1-5)', type: 'number' },
      { name: 'review', label: 'Review', type: 'text' },
    ],
  },
};

export const entityOrder = [
  'stations', 'platforms', 'users', 'porters', 'bookings', 'payments', 'ratings',
];
